from calc import suma, multiplicacion, division
print("2 + 3 = ",suma(2, 3))
print("2 * 3 = ",multiplicacion(2, 3))
print("6 / 3 = ",division(6, 3))
