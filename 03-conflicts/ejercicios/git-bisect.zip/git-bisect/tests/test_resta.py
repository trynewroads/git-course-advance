from operaciones.resta import resta


def test_resta_positivos():
    assert resta(5, 3) == 2


def test_resta_negativos():
    assert resta(-2, -3) == 1


def test_resta_mixta():
    assert resta(-2, 3) == -5


def test_resta_ceros():
    assert resta(0, 0) == 0