from operaciones.multiplicacion import multiplicacion


def test_multiplicacion_positivos():
    assert multiplicacion(2, 3) == 6
    
def test_multiplicacion_negativos():
    assert multiplicacion(-2, -3) == 6

def test_multiplicacion_mixta():
    assert multiplicacion(-2, 3) == -6


def test_multiplicacion_ceros():
    assert multiplicacion(0, 0) == 0