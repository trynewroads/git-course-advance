from operaciones.division import division


def test_division_positivos():
    assert division(6, 3) == 2.0

def test_division_negativos():
    assert division(-6, -3) == 2.0

def test_division_mixta():
    assert division(-6, 3) == -2.0

