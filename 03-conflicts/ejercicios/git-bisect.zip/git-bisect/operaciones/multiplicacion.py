def multiplicacion(a, b):
    """Multiplicación simple"""
    return a * b