def resta(a, b):
    """Resta b de a"""
    return a - b