def division(a, b):
    """División (float)"""
    return a / b